from controller import Robot, Camera, InertialUnit, GPS, Compass, Gyro, Motor, Emitter
import math
import numpy as np
import struct

# create the Robot instance.
robot = Robot()

# get the time step of the current world.
timestep = int(robot.getBasicTimeStep())
emitter = robot.getEmitter("emitter")

# send data
message = struct.pack('5f', 0.0, 0.0, 0.0, 0.0, 0.0)
emitter.send(message)

imu = robot.getInertialUnit("inertial unit")
imu.enable(timestep)
camera = robot.getCamera("camera")
camera.enable(timestep)
gps = robot.getGPS("gps")
gps.enable(timestep)
compass = robot.getCompass("compass")
compass.enable(timestep)
gyro = robot.getGyro("gyro")
gyro.enable(timestep)

front_left_motor = robot.getMotor("front left propeller")
front_right_motor = robot.getMotor("front right propeller")
rear_left_motor = robot.getMotor("rear left propeller")
rear_right_motor = robot.getMotor("rear right propeller")
motors = [front_left_motor, front_right_motor, rear_left_motor, rear_right_motor]

# arming
for i in range(4):
    motors[i].setPosition(float("inf"))
    motors[i].setVelocity(1.0)

k_vertical_thrust = 68.5
k_vertical_offset = 0.6
k_vertical_p = 3.0  
k_roll_p = 50.0
k_pitch_p = 30.0
target_altitude = 10.0 

roll_disturbance = 0
pitch_disturbance = 0
yaw_disturbance = 0

# Define the S trajectory
start_time = robot.getTime()
takeoff_duration = 10  # Takeoff time
s_duration = 30  # S-shaped path flight time
landing_duration = 20  # Landing time
flight_duration = takeoff_duration + s_duration + landing_duration
end_time = start_time + flight_duration

def convert_to_pitch_roll(ex, ey, yaw):
    c, s = np.cos(yaw), np.sin(yaw)
    R = np.array(((c, -s), (s, c)))
    exy_ = np.matmul([ex, ey], R)
    return exy_[0], exy_[1]

# Main loop:
while robot.step(timestep) != -1:
    
    roll = imu.getRollPitchYaw()[0] + math.pi / 2.0
    pitch = imu.getRollPitchYaw()[1]
    yaw = imu.getRollPitchYaw()[2]
    altitude = gps.getValues()[1]
    px = gps.getValues()[0]
    py = gps.getValues()[2]

    current_time = robot.getTime()
    
    if current_time - start_time < takeoff_duration:  # Takeoff phase
        target_x = 0.0
        target_y = 0.0
        target_z = 10.0
    elif current_time - start_time < takeoff_duration + s_duration:  # S-shaped path phase
        t = current_time - start_time - takeoff_duration
        target_x = -7.0 * np.sin(t * np.pi / s_duration)  # S-shape along x-axis
        target_y = 7.0 * np.sin(t * np.pi / s_duration)  # S-shape along y-axis
        target_z = 10.0
    elif current_time - start_time < flight_duration:  # Return to origin and land phase
        target_x = 0.0
        target_y = 0.0
        target_z = max(0, 10.0 - (current_time - (start_time + takeoff_duration + s_duration)) * 0.5)  # Descending gradually
    else:
        target_x = 0.0
        target_y = 0.0
        target_z = 0.0  # Landed
    
    if current_time >= end_time and altitude <= 0.1:  # Ensure the drone has landed
        # Set all motor velocities to zero
        for motor in motors:
            motor.setVelocity(0)
        # No need to proceed further in the loop if landed
        break

    roll_acceleration = gyro.getValues()[0]
    pitch_acceleration = gyro.getValues()[1]
    
    pitch_err, roll_err = convert_to_pitch_roll(px - target_x, target_y - py, yaw)
    
    roll_input = k_roll_p * np.clip(roll, -1.0, 1.0) + roll_acceleration - roll_err
    pitch_input = k_pitch_p * np.clip(pitch, -1.0, 1.0) - pitch_acceleration - pitch_err
    yaw_input = yaw_disturbance
    clamped_difference_altitude = np.clip(target_z - altitude + k_vertical_offset, -1.0, 1.0)
    vertical_input = k_vertical_p * math.pow(clamped_difference_altitude, 3.0)

    front_left_motor_input = k_vertical_thrust + vertical_input - roll_input - pitch_input + yaw_input
    front_right_motor_input = k_vertical_thrust + vertical_input + roll_input - pitch_input - yaw_input
    rear_left_motor_input = k_vertical_thrust + vertical_input - roll_input + pitch_input - yaw_input
    rear_right_motor_input = k_vertical_thrust + vertical_input + roll_input + pitch_input + yaw_input
    
    front_left_motor.setVelocity(front_left_motor_input)
    front_right_motor.setVelocity(-front_right_motor_input)
    rear_left_motor.setVelocity(-rear_left_motor_input)
    rear_right_motor.setVelocity(rear_right_motor_input)

    message = struct.pack('5f', target_x, target_y, target_z, yaw, yaw_disturbance)
    emitter.send(message)
